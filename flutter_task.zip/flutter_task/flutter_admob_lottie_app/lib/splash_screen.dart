import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:lottie/lottie.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'main_screen.dart';

class SplashScreen extends StatefulWidget {
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  InterstitialAd? _interstitialAd;
  NativeAd? _nativeAd;
  bool _isInterstitialLoaded = false;
  bool _isNativeLoaded = false;

  @override
  void initState() {
    super.initState();
    _startSplashLogic();
  }

  void _startSplashLogic() async {
    var connectivityResult = await Connectivity().checkConnectivity();
    bool isConnected = connectivityResult != ConnectivityResult.none;

    if (!isConnected) {
      // No network: wait 2 sec, go to main screen without loading ads
      await Future.delayed(Duration(seconds: 2));
      _navigateToMain();
      return;
    }

    // Start 8-second ad loading timeout
    Timer(Duration(seconds: 8), () {
      if (!_isInterstitialLoaded) {
        _navigateToMain(); // Timeout fallback
      }
    });

    _loadInterstitialAd();
    _loadNativeAd();

    // Navigate after 4s animation
    Future.delayed(Duration(seconds: 4), () {
      if (_isInterstitialLoaded) {
        _interstitialAd!.show();
        _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
          onAdDismissedFullScreenContent: (ad) {
            _navigateToMain();
          },
          onAdFailedToShowFullScreenContent: (ad, error) {
            _navigateToMain();
          },
        );
      } else {
        _navigateToMain(); // If ad isn't ready in 4s
      }
    });
  }

  void _loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: 'ca-app-pub-4956629062469285/7330069332',
      request: AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _isInterstitialLoaded = true;
        },
        onAdFailedToLoad: (error) {
          _isInterstitialLoaded = false;
        },
      ),
    );
  }

  void _loadNativeAd() {
    _nativeAd = NativeAd(
      adUnitId: 'ca-app-pub-4956629062469285/6016987667',
      factoryId: 'adFactoryExample', // This will be used in MainScreen later
      listener: NativeAdListener(
        onAdLoaded: (ad) {
          setState(() {
            _isNativeLoaded = true;
          });
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          _isNativeLoaded = false;
        },
      ),
      request: AdRequest(),
    )..load();
  }

  void _navigateToMain() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) =>
            MainScreen(nativeAd: _isNativeLoaded ? _nativeAd : null),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Lottie.asset(
          'assets/progress.json', // Make sure to download a Lottie animation and place it in assets
          width: 200,
          height: 200,
          repeat: false,
        ),
      ),
    );
  }
}
