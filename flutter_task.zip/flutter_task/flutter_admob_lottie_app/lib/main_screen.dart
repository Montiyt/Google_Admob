import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class MainScreen extends StatefulWidget {
  final NativeAd? nativeAd;

  const MainScreen({Key? key, this.nativeAd}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with WidgetsBindingObserver {
  InterstitialAd? _resumedInterstitialAd;
  bool _isInterstitialLoaded = false;
  bool _hasResumedOnce = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    if (widget.nativeAd != null) {
      widget.nativeAd!.load();
    }

    _loadResumedInterstitialAd();
  }

  void _loadResumedInterstitialAd() {
    InterstitialAd.load(
      adUnitId: 'ca-app-pub-4956629062469285/7330069332',
      request: AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _resumedInterstitialAd = ad;
          _isInterstitialLoaded = true;
        },
        onAdFailedToLoad: (error) {
          _isInterstitialLoaded = false;
        },
      ),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !_hasResumedOnce) {
      _hasResumedOnce = true;

      if (_isInterstitialLoaded && widget.nativeAd != null) {
        Future.delayed(Duration(seconds: 2), () {
          _resumedInterstitialAd!.show();
          _resumedInterstitialAd!.fullScreenContentCallback =
              FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              setState(() {
                _hasResumedOnce = false;
              });
            },
            onAdFailedToShowFullScreenContent: (ad, error) {
              setState(() {
                _hasResumedOnce = false;
              });
            },
          );
        });
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _resumedInterstitialAd?.dispose();
    widget.nativeAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Main Screen"),
        backgroundColor: Colors.teal,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(child: Text("🎉 Welcome to the Main Screen!")),
          SizedBox(height: 20),
          if (widget.nativeAd != null)
            Container(
              height: 100,
              margin: EdgeInsets.all(16),
              child: AdWidget(ad: widget.nativeAd!),
            )
          else
            Text("No native ad was loaded."),
        ],
      ),
    );
  }
}
